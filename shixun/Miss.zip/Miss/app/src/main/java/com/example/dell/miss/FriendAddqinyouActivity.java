package com.example.dell.miss;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class FriendAddqinyouActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.friend_addfriend);

        TextView back = findViewById(R.id.tv_addqinyouback);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        EditText name = findViewById(R.id.et_qinyouName);
        EditText time = findViewById(R.id.et_qinyouTime);
        EditText position = findViewById(R.id.et_qinyouProsition);
        EditText description = findViewById(R.id.et_qinyouDescription);
        EditText shengping = findViewById(R.id.et_qinyouShengping);
        EditText mudi = findViewById(R.id.et_qinyouMudi);

        //获得到用户在添加页面输入的信息。将信息存入数据库，更新列表



        Button ok = findViewById(R.id.btn_addqinyou_ok);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }
}

