package com.example.dell.miss;

public class Constant {
    public static int HEART_COUNTDOWN_START = 6;
    public static int HEART_COUNTDOWN_STOP = 7;
    public static int HRART_PIANGAO = 8;
    public static int HRART_ZHENGCHANG = 9;
    public static int HRART_PIANDI = 10;

    public static final String URL = "http://192.168.43.10:8080/QuietNightProject/";
    public static final int EVENT_GET_VERIFICATION_CODE = 2;
    public static final int EVENT_GET_SUPPORTED_COUNTRIES = 3;
    public static final int EVENT_SUBMIT_VERIFICATION_CODE = 1;
    public static final int RESEND_VERIFICATION_CODE_FLAG = 4;//获取验证码时更改按钮上的数字倒计时
    public static final int GET_VERIFICATION_CODE_FLAG = 5;


}
