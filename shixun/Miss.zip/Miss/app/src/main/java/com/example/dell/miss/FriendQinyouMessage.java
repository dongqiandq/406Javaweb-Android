package com.example.dell.miss;

import java.util.ArrayList;

public class FriendQinyouMessage {
    public String name;
    public String time;
    public String possition;
    public String description;
    public ArrayList<Integer> lookNum = new ArrayList<>();
}
