package com.example.dell.miss;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class FriendFragment extends Fragment  {
    private List<FriendQinyouMessage> list = new ArrayList<>();
    private ListView listView;
    private FriendQinyouAdapter adapter;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.friend,container,false);
        initData();
        findView(view);
        ImageView add = view.findViewById(R.id.img_add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(),FriendAddqinyouActivity.class);
                startActivity(intent);
            }
        });
        return view;
    }
    private void findView(View view){
        listView = view.findViewById(R.id.lv_qinyou);
        adapter = new FriendQinyouAdapter(getContext(),list,R.layout.friend_list_item);

        listView.setAdapter(adapter);
    }

    private void initData(){
        FriendQinyouMessage qinyouMessage = new FriendQinyouMessage();
        qinyouMessage.name = "王烁";
        qinyouMessage.time = "1984 - 2020";
        qinyouMessage.possition = "辽宁省";
        qinyouMessage.description = "精忠报国，大爱无疆，和不不不中年男子你在哪哈卡阿克汉好的吧报酬吧智能化撒娇北京南站";

        FriendQinyouMessage qinyouMessage1 = new FriendQinyouMessage();
        qinyouMessage1.name = "李文亮";
        qinyouMessage1.time = "19744 - 2020";
        qinyouMessage1.possition = "湖北省";
        qinyouMessage1.description = "医德高尚，救死扶伤";
        list.add(qinyouMessage);
        list.add(qinyouMessage1);

    }
}
