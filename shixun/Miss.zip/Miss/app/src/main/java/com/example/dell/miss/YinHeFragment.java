package com.example.dell.miss;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class YinHeFragment extends Fragment {
    private ListView listView;
    private ZhuiyiAdapter zhuiyiAdapter = null;
    private List<ZhuiyiMessage> list = new ArrayList<>();
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.yinhe_layout,container,false);
        listView = view.findViewById(R.id.lv_zyinhe);
        initData();
        zhuiyiAdapter = new ZhuiyiAdapter(list,getContext(),R.layout.zhuiyi_item);
        listView.setAdapter(zhuiyiAdapter);
        return view;
    }
    private void initData(){
        list.clear();

        ZhuiyiMessage zhuiyiMessage3 = new ZhuiyiMessage(R.drawable.second,"周恩来","1898年3月-1976年1月","北京");
        zhuiyiMessage3.setContext("热爱祖国，热爱人民，为了人民的利益奔走一生。");
        list.add(zhuiyiMessage3);

        ZhuiyiMessage zhuiyiMessage1 = new ZhuiyiMessage();
        zhuiyiMessage1.setImgId(R.drawable.libai);
        zhuiyiMessage1.setZyname("李白");
        zhuiyiMessage1.setZyyear("701年—762年");
        zhuiyiMessage1.setZyaddress("安徽省马鞍山市");
        zhuiyiMessage1.setContext("李白（701年—762年） ，字太白，号青莲居士，又号“谪仙人”。是唐代伟大的浪漫主义诗人，被后人誉为“诗仙”。" );
        list.add(zhuiyiMessage1);

        ZhuiyiMessage zhuiyiMessage6 = new ZhuiyiMessage(R.drawable.second,"邓稼先","1924年6月-1986年7月","北京");
        zhuiyiMessage6.setContext("两弹元勋。");
        list.add(zhuiyiMessage6);

        ZhuiyiMessage zhuiyiMessage2 = new ZhuiyiMessage();
        zhuiyiMessage2.setImgId(R.drawable.dufu);
        zhuiyiMessage2.setZyname("杜甫");
        zhuiyiMessage2.setZyyear("公元712年-公元770年");
        zhuiyiMessage2.setZyaddress("洛阳偃师首阳山");
        zhuiyiMessage2.setContext("杜甫（公元712年-公元770年），字子美，自号少陵野老。汉族，祖籍襄阳，河南巩县（今河南省巩义）人。唐代伟大的现实主义诗人，与李白合称“李杜”。");
        list.add(zhuiyiMessage2);

        ZhuiyiMessage zhuiyiMessage4 = new ZhuiyiMessage(R.drawable.second,"邓小平","1904年8月-1997年2月","北京");
        zhuiyiMessage4.setContext("为了中国的统一奔波忙碌，关心人民，伟大的领袖。");
        list.add(zhuiyiMessage4);

        ZhuiyiMessage zhuiyiMessage7 = new ZhuiyiMessage();
        zhuiyiMessage7.setImgId(R.drawable.dumu);
        zhuiyiMessage7.setZyname("杜牧");
        zhuiyiMessage7.setZyyear("公元803-公元约852年");
        zhuiyiMessage7.setZyaddress("西安");
        zhuiyiMessage7.setContext("杜牧(公元803-公元约852年)，字牧之，号樊川居士，汉族，京兆万年(今陕西西安)人。杜牧是唐代杰出的诗人、散文家，是宰相杜佑之孙，杜从郁之子。");
        list.add(zhuiyiMessage7);

        ZhuiyiMessage zhuiyiMessage5 = new ZhuiyiMessage(R.drawable.second,"毛泽东","1893年12月-1976年9月","北京");
        zhuiyiMessage5.setContext("为了中国的统一奔波忙碌，关心人民，伟大的领袖。");
        list.add(zhuiyiMessage5);


    }
}
