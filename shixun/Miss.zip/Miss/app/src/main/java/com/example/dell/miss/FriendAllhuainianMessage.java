package com.example.dell.miss;

public class FriendAllhuainianMessage {
    public String upName;
    public String upTime;
    public String upDescription;
}
