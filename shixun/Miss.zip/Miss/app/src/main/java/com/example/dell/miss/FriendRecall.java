package com.example.dell.miss;

public class FriendRecall {
    public String title;
    public String time;
    public String description;
}
