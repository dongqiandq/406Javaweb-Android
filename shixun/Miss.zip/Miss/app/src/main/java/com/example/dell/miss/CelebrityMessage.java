package com.example.dell.miss;

public class CelebrityMessage {
    public String cename;
    public String cetime;
    public String cepossition;
    public String cedescription;
}
