package com.example.dell.miss;

public class Words {
	private Integer id;
	private User user;
	private Galaxy galaxy;
	private String content;

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Galaxy getGalaxy() {
		return galaxy;
	}
	public void setGalaxy(Galaxy galaxy) {
		this.galaxy = galaxy;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
}
