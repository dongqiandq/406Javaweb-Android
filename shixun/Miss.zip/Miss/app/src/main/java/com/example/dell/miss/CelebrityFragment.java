package com.example.dell.miss;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class CelebrityFragment extends Fragment {
    private List<CelebrityMessage> list = new ArrayList<>();
    private ListView listView;
    private CelebrityAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.activity_celebrity,container,false);
        initData();
        findView(view);

        return view;
    }


    private void findView(View view){
        listView = view.findViewById(R.id.lv_celebrity);
        adapter = new CelebrityAdapter(list,R.layout.friend_list_item,getContext());
        listView.setAdapter(adapter);
    }

    private void initData(){
        CelebrityMessage message = new CelebrityMessage();
        message.cename = "周恩来";
        message.cetime = "XXXX-XXXX";
        message.cepossition = "北京市";
        message.cedescription = "热爱祖国，热爱人民，为了人民的利益奔走一生。";
        CelebrityMessage message1 = new CelebrityMessage();
        message1.cename = "邓小平";
        message1.cetime = "XXXX-XXXX";
        message1.cepossition = "北京";
        message1.cedescription = "为了中国的统一奔波忙碌，关心人民，伟大的领袖。";
        CelebrityMessage message3 = new CelebrityMessage();
        message3.cename = "毛泽东";
        message3.cetime = "XXXX-XXXX";
        message3.cepossition = "北京";
        message3.cedescription = "为了中国的统一奔波忙碌，关心人民，伟大的领袖。";
        CelebrityMessage message4 = new CelebrityMessage();
        message4.cename = "邓稼先";
        message4.cetime = "XXXX-XXXX";
        message4.cepossition = "北京";
        message4.cedescription = "两弹元勋。";
        list.add(message);
        list.add(message1);
        list.add(message3);
        list.add(message4);
    }
}
