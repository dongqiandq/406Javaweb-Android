package com.quietnight.entity;

public class Famous {

}
